//MOTOR
#define speed 70
#define tunnel 95
#define Stability 8
#define maxtime 3000

#define IN1 0x80 // RB7
#define IN2 0x40 // RB6
#define IN3 0x10 // RB4
#define IN4 0x08 // RB3

//SENSORS
#define IR_Right 0x01  // RD0 line
#define IR_Left  0x08  // RD3 line
#define Wall_Left  0x10 // RD4 wall
#define Wall_Right 0x20 // RD5 wall
#define Turn 40

//LDR
#define threshold 450
#define Buzzer 0x02      // RA1

//ULTRASONIC
#define Trig 0x02 // RB1
#define Echo 0x20 // RA5

#define Obstacle 25
#define Reverse 300
#define Stop 80
#define Recheck 120
#define Scan_turn 240
#define Left_extra 140
#define Right_extra 100
#define Decide 360
#define Settle 420

//PARKING
#define Forward 350
#define Park 400

//SERVO
#define servo 0x02       // RE1
#define angle 1500
#define hold 60

//LED
#define LED 0x40         // RC6

volatile unsigned long g_ms = 0;

typedef enum {
    LineFollow,
    Tunnel,
    Avoid,
    Parking
} SystemState;

SystemState currentState = LineFollow;


//Delay
void Timer0_Init() {
    OPTION_REG = 0x84; // Prescaler 1:32
    TMR0 = 193;
    T0IF_bit = 0;
    T0IE_bit = 1;
    GIE_bit = 1;
}

void interrupt() {
    if (T0IF_bit) {
        TMR0 = 193;
        g_ms++;
        T0IF_bit = 0;
    }
}

void delay(unsigned int ms) {
    unsigned long start = g_ms;
    while ((unsigned long)(g_ms - start) < ms);
}


//LDR
void ADC_init() {
    ADCON1 = 0x8E;  // AN0 analog only
    ADCON0 = 0x41;
    TRISA |= 0x01;  // RA0 input
}

unsigned int LDR_Read() {
    ADCON0 &= 0xC7;  // select AN0
    Delay_us(20);
    GO_DONE_bit = 1;
    while (GO_DONE_bit);
    return ((unsigned int)ADRESH << 8) | ADRESL;
}


//Timer1
void delay_tmr1(unsigned int us) {
    unsigned int target;
    unsigned char oldT1CON = T1CON;

    T1CON = 0x01;
    TMR1H = 0;
    TMR1L = 0;
    target = us * 2;

    while ((((unsigned int)TMR1H << 8) | TMR1L) < target);
    T1CON = oldT1CON;
}

void Servo_Move(unsigned int high_us, unsigned int frames) {
    unsigned int i;
    for (i = 0; i < frames; i++) {
        PORTE |= servo;
        delay_tmr1(high_us);
        PORTE &= ~servo;
        delay(20);
    }
}


//PWM
void PWM_Init() {
    TRISC &= ~(0x06);
    PR2 = 124;
    T2CON = 0x05;
    CCP1CON = 0x0C;
    CCP2CON = 0x0C;
    CCPR1L = 0;
    CCPR2L = 0;
    delay(5);
}

void rotateMotor(int rightSpeed, int leftSpeed) {
    if (rightSpeed < 0) { PORTB &= ~IN3; PORTB |= IN4; rightSpeed = -rightSpeed; }
    else if (rightSpeed > 0) { PORTB |= IN3; PORTB &= ~IN4; }
    else { PORTB &= ~(IN3 | IN4); }

    if (leftSpeed < 0) { PORTB &= ~IN1; PORTB |= IN2; leftSpeed = -leftSpeed; }
    else if (leftSpeed > 0) { PORTB |= IN1; PORTB &= ~IN2; }
    else { PORTB &= ~(IN1 | IN2); }

    if (rightSpeed > 255) rightSpeed = 255;
    if (leftSpeed  > 255) leftSpeed  = 255;

    CCPR2L = (unsigned char)rightSpeed;
    CCPR1L = (unsigned char)leftSpeed;
}


//Ultrasonic
unsigned int Ultrasonic_Read() {
    unsigned int ticks, timeout;

    PORTB &= ~Trig;
    Delay_us(2);
    PORTB |= Trig;
    Delay_us(10);
    PORTB &= ~Trig;

    timeout = 50000;
    while (((PORTA & Echo) == 0) && timeout) timeout--;
    if (timeout == 0) return 999;

    T1CON = 0x01;
    TMR1H = 0;
    TMR1L = 0;

    timeout = 50000;
    while (((PORTA & Echo) != 0) && timeout) timeout--;

    T1CON = 0x00;
    if (timeout == 0) return 999;

    ticks = ((unsigned int)TMR1H << 8) | TMR1L;
    return (unsigned int)(ticks / 116);
}


//Line Follow
void LineFollowMode(unsigned char rightIR, unsigned char leftIR, unsigned char spd) {
    if (!rightIR && !leftIR) rotateMotor(spd, spd);
    else if (!rightIR && leftIR) rotateMotor(spd, -spd);
    else if (rightIR && !leftIR) rotateMotor(-spd, spd);
    else rotateMotor(spd, -spd);
}


//Beep
void delay_with_beep(unsigned int ms) {
    unsigned long start = g_ms;

    while ((unsigned long)(g_ms - start) < ms) {
        if (((unsigned int)(g_ms % 1000)) < 100) PORTA |= Buzzer;
        else PORTA &= ~Buzzer;
    }
}


//Obstacle Avoid
void AvoidObstacle() {
    unsigned int dL, dR;

    rotateMotor(0, 0);
    delay(Stop);

    rotateMotor(-speed, -speed);
    delay(Reverse);

    rotateMotor(0, 0);
    delay(Stop);

    rotateMotor(speed, -speed);
    delay(Scan_turn + Left_extra);
    rotateMotor(0, 0);
    delay(Settle);
    dL = Ultrasonic_Read();

    rotateMotor(-speed, speed);
    delay((Scan_turn * 2) + Right_extra);
    rotateMotor(0, 0);
    delay(Settle);
    dR = Ultrasonic_Read();

    rotateMotor(speed, -speed);
    delay(Scan_turn + Left_extra + Right_extra);
    rotateMotor(0, 0);
    delay(80);

    if (dL >= dR) {
        rotateMotor(speed, -speed);
        delay(Decide);
    } else {
        rotateMotor(-speed, speed);
        delay(Decide);
    }

    rotateMotor(speed, speed);
    delay(180);
    rotateMotor(0, 0);
    delay(80);
}


//Parking
void DoParking() {
    unsigned int dL, dR;

    rotateMotor(speed, speed);
    delay_with_beep(Forward);

    rotateMotor(0, 0);
    delay_with_beep(Stop);

    rotateMotor(speed, -speed);
    delay_with_beep(Scan_turn + Left_extra);
    rotateMotor(0, 0);
    delay_with_beep(Settle);
    dL = Ultrasonic_Read();

    rotateMotor(-speed, speed);
    delay_with_beep((Scan_turn * 2) + Right_extra);
    rotateMotor(0, 0);
    delay_with_beep(Settle);
    dR = Ultrasonic_Read();

    rotateMotor(speed, -speed);
    delay_with_beep(Scan_turn + Left_extra + Right_extra);
    rotateMotor(0, 0);
    delay_with_beep(80);

    if (dL >= dR) {
        rotateMotor(speed, -speed);
        delay_with_beep(Park);
    } else {
        rotateMotor(-speed, speed);
        delay_with_beep(Park);
    }

    rotateMotor(0, 0);
    Servo_Move(angle, hold);

    PORTA &= ~Buzzer;
    PORTC &= ~LED;
}


//MAIN
void main() {

    unsigned long tunnelStartMs;
    unsigned char rightIR, leftIR, ldrVal;
    unsigned char wallL, wallR;
    unsigned int distance;
    unsigned int ldrAdc;
    unsigned char tunnelExitCount = 0;

    ADC_init();
    TRISE &= ~servo;
    PORTE &= ~servo;

    TRISB &= ~(0xD8 | Trig);
    TRISD |= (IR_Right | IR_Left | Wall_Left | Wall_Right);

    TRISA &= ~(Buzzer);
    TRISA |= (Echo);

    TRISC &= ~LED;
    PORTC &= ~LED;

    PORTB = 0x00;
    PORTA &= ~(Buzzer);

    Timer0_Init();
    PWM_Init();

    delay(3000);
    PORTC |= LED;
    tunnelStartMs = 0;

    while(1) {
        rightIR = (PORTD & IR_Right) ? 1 : 0;
        leftIR  = (PORTD & IR_Left)  ? 1 : 0;

        ldrAdc = LDR_Read();
        ldrVal = (ldrAdc < threshold) ? 1 : 0;

        wallL = (PORTD & Wall_Left)  ? 1 : 0;
        wallR = (PORTD & Wall_Right) ? 1 : 0;

        switch(currentState) {

            case LineFollow:
                LineFollowMode(rightIR, leftIR, speed);
                if (ldrVal) {
                    PORTA |= Buzzer;
                    tunnelStartMs = g_ms;
                    tunnelExitCount = 0;
                    currentState = Tunnel;
                }
                break;

            case Tunnel:
                LineFollowMode(rightIR, leftIR, tunnel);

                if (!ldrVal) {
                    if (tunnelExitCount < 255) tunnelExitCount++;
                } else tunnelExitCount = 0;

                if (tunnelExitCount >= Stability || (unsigned long)(g_ms - tunnelStartMs) >= maxtime) {
                    PORTA &= ~Buzzer;
                    currentState = Avoid;
                }
                break;

            case Avoid:
                if (rightIR && leftIR) {
                    currentState = Parking;
                    break;
                }

                distance = Ultrasonic_Read();
                if (distance <= Obstacle) AvoidObstacle();
                else if (wallL && !wallR) rotateMotor(Turn, speed);
                else if (wallR && !wallL) rotateMotor(speed, Turn);
                else rotateMotor(speed, speed);

                delay(Recheck);
                break;

            case Parking:
                DoParking();
                while(1) {
                    rotateMotor(0, 0);
                    PORTA &= ~Buzzer;
                    PORTC &= ~LED;
                }
                break;
        }
    }
}
